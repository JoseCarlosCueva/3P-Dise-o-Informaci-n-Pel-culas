String host = 'api.themoviedb.org';

String endpoint = '/3/movie/popular';

String moviesTopRated = '....';

String token =
    'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzZjMxYjQ0MmMxYTQ5MzcwZTU0ZjhhZTljYWU3MzhhMCIsIm5iZiI6MTc2MDE1MzIzNS41MzIsInN1YiI6IjY4ZTljZTkzOTEyZTE0ZTkwZTY0NTYwMSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.sFLOulQntPh2sZScfTRtEk9pujDnRLyTbC3LbK9nxMk';
